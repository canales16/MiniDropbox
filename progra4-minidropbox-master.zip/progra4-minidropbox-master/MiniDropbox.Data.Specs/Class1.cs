﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MiniDropbox.Data.Specs
{
    public class Class1
    {
    }
}
