﻿using System.Collections.Generic;
using System.Web.Mvc;
using Machine.Specifications;
using Machine.Specifications.Mvc;
using MiniDropbox.Web.Controllers;
using MiniDropbox.Web.Models;

namespace MiniDropbox.Web.Specs
{
    public class when_a_register_user_tries_to_login_with_correct_values
    {
        private Establish context = () =>
            {
                _diskController = new DiskController();
            };

        private Because of = () => {
                                       _result = _diskController.ListAllContent();
        };

        private It should_display_a_view_for_viewing_files = () =>
            {
                _result.ShouldBeAView().And().Model.ShouldBeOfType<List<DiskContentModel>>();
            };

        private static DiskController _diskController;
        private static ActionResult _result;
    }
}