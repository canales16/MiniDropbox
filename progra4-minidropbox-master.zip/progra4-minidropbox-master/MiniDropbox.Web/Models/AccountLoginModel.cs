﻿namespace MiniDropbox.Web.Models
{
    public class AccountLoginModel
    {
        public string Username;
        public string Password;
    }
}