﻿namespace MiniDropbox.Web.Models
{
    public class DiskContentModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Type { get; set; }
        public string ModifiedDate { get; set; }
    }
}